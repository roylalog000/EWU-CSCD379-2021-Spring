namespace SecretSanta.Data
{
    public class Gift
    {
        //public int Id { get; set; }
        public int GiftId { get; set; }
        public string Title { get; set; } = "";
        public int RecieverId { get; set; }
        
        public int UserId { get; set; }
    }
}