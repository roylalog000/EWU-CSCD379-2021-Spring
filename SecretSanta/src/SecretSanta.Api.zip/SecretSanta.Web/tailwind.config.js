module.exports = {
    purge: ['./**/*.html', './**/*.cshtml'],
    theme: {
        extend: {}
    },
    variants: {
    },
    plugins: []
}