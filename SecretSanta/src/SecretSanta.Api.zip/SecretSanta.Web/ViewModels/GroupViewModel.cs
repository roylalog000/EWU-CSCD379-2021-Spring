namespace SecretSanta.Web.ViewModels
{
    public class GroupViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
    }
}