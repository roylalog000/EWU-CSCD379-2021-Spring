﻿namespace SecretSanta.Api.Dto
{
    public class NewGroup
    {
        public string? Name { get; set; }
    }
}
