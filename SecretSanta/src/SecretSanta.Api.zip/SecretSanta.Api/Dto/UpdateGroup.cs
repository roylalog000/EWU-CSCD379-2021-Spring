﻿namespace SecretSanta.Api.Dto
{
    public class UpdateGroup
    {
        public string? Name { get; set; }
    }
}
