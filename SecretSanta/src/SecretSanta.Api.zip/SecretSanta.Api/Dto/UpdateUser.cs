﻿namespace SecretSanta.Api.Dto
{
    public class UpdateUser
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
    }
}
